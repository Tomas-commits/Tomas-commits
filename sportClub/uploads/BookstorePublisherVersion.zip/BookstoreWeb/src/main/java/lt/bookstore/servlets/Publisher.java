package lt.bookstore.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import lt.bookstore.db.Db;
import lt.bookstore.models.book.Book;

/**
 * Servlet implementation class HomeServlet
 */
@SuppressWarnings("unused")
@WebServlet("/publisher")
public class Publisher extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Publisher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		Session session=Db.getSessionFactory().openSession();		

		List<lt.bookstore.models.book.Publisher> publisher = session.createQuery("SELECT p FROM Publisher p", lt.bookstore.models.book.Publisher.class).getResultList();
		session.close();

		request.setAttribute("publisher", publisher);
		
		RequestDispatcher dispatcher=request.getRequestDispatcher("/publisher.jsp");
		dispatcher.forward(request, response);

	}
}
