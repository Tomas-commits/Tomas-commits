package lt.bookstore.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import lt.bookstore.db.Db;
import lt.bookstore.models.book.Book;
import lt.bookstore.models.book.Publisher;

/**
 * Servlet implementation class updateBook
 */
@WebServlet("/updateBook")
public class UpdateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer id=Integer.parseInt(request.getParameter("id"));
		Session session=Db.getSessionFactory().openSession();
		Book b=session.get(Book.class, id);
		
		List<lt.bookstore.models.book.Publisher> publishers=session.createQuery("SELECT p FROM Publisher p", Publisher.class).getResultList();
		
		
		System.out.println(b.getId());
		
		session.close();
		
		request.setAttribute("book", b);
		request.setAttribute("publishers", publishers);
		
		RequestDispatcher dispatcher=request.getRequestDispatcher("updateBook.jsp");
		dispatcher.forward(request, response);
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Veikia");
		Integer id=Integer.parseInt(request.getParameter("id"));
		Integer publisherId=Integer.parseInt(request.getParameter("publisher_id"));
		String name = request.getParameter("name");
		String author = request.getParameter("author");
		String year = request.getParameter("year");
		Integer isbnNumber = Integer.parseInt(request.getParameter("isbnNumber"));
		Integer pages = Integer.parseInt(request.getParameter("pages"));
		
		Session session=Db.getSessionFactory().openSession();
		session.beginTransaction();
		
		
		Publisher p=session.get(Publisher.class, publisherId);
		Book b=session.get(Book.class, id);
		b.setName(name);
		b.setAuthor(author);
		b.setYear(year);
		b.setIsbnNumber(isbnNumber);
		b.setPages(pages);
		b.setPublisher(p);
		
		System.out.println(b.getPublisher());
		
		session.save(b);		
		session.getTransaction().commit();
		session.close();
		
		response.sendRedirect( request.getContextPath()+"/home");
	}

}
