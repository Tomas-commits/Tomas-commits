package lt.bookstore.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import lt.bookstore.db.Db;
import lt.bookstore.models.book.Book;
import lt.bookstore.models.book.Publisher;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Session tmpSession=Db.getSessionFactory().openSession();
		tmpSession.beginTransaction();
		
//		Publisher p=new Publisher("HarperOne", "United States", "San Francisco, California");
//		tmpSession.save(p);
		
//		Book b=tmpSession.get(Book.class, 5);
//		Publisher p=tmpSession.get(Publisher.class, 1);		
//		b.setPublisher(p);		
//		System.out.println(b.getPublisher().getName());
//		System.out.println(b.getName());
		
		
		tmpSession.getTransaction().commit();
		tmpSession.close();
		
		
		
		
		
		
		
		Session session=Db.getSessionFactory().openSession();		
		//session.get - paimti įrašą, Product.class- nurodo kokio modelio įrašą paimam, 2 - ID laukelio reikšmė
		//		Book b= session.get(Book.class, 1);
		//		System.out.println(b);
		List<Book> books = session.createQuery("SELECT b FROM Book b", Book.class).getResultList();
		session.close();
		
		
		
		request.setAttribute("books", books);
		
		RequestDispatcher dispatcher=request.getRequestDispatcher("/home.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
