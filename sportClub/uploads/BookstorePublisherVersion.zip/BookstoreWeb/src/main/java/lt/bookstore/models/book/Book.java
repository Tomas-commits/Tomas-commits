package lt.bookstore.models.book;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity	
@Table(name="books")
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String author;
	@Column
	private String name;
	@Column
	private String year;
	@Column
	private int pages;
	@Column
	private int isbnNumber;
	@ManyToOne
	@JoinColumn(name = "publisher_id")
	private Publisher publisher;
	
	
	
	public Publisher getPublisher() {
		return publisher;
	}


	public void setPublisher(Publisher publisher) {
		this.publisher = publisher;
	}


	public Book() {
		super();
	}


	public Book(String author, String name, String year, int pages, int isbnNumber) {
		super();
		this.author = author;
		this.name = name;
		this.year = year;
		this.pages = pages;
		this.isbnNumber = isbnNumber;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getYear() {
		return year;
	}


	public void setYear(String year) {
		this.year = year;
	}


	public int getPages() {
		return pages;
	}


	public void setPages(int pages) {
		this.pages = pages;
	}


	public int getIsbnNumber() {
		return isbnNumber;
	}


	public void setIsbnNumber(int isbnNumber) {
		this.isbnNumber = isbnNumber;
	}


	@Override
	public String toString() {
		return "Book [author=" + author + ", name=" + name + ", year=" + year + ", pages=" + pages + ", isbnNumber="
				+ isbnNumber + "]";
	}
	
	
	

}
