package lt.bookstore.db;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Db {
	private static Db db=null;
	private SessionFactory sf=null;
	
	private Db() {
		//Prisijungimas prie Hibernate i� dokumentacijos
		StandardServiceRegistry sr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata md=new MetadataSources(sr).getMetadataBuilder().build();
		sf=md.getSessionFactoryBuilder().build();
	}
	
	public static SessionFactory getSessionFactory() {
		if (db==null) {
			db=new Db();
		}
		return db.getSf();
	}

	public SessionFactory getSf() {
		return sf;
	}

	public void setSf(SessionFactory sf) {
		this.sf = sf;
	}
	
	

}
